#include "lcd_init.h"
#include "rtthread.h"

void LCD_GPIO_Init(void)
{   /*
    GPIO_InitTypeDef  GPIO_InitStructure;
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOG|RCC_APB2Periph_GPIOD|RCC_APB2Periph_GPIOE, ENABLE);  //ʹ��A�˿�ʱ��
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;         //�������
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;//�ٶ�50MHz
    GPIO_Init(GPIOG, &GPIO_InitStructure);
    GPIO_SetBits(GPIOG,GPIO_Pin_12);

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1|GPIO_Pin_4|GPIO_Pin_5|GPIO_Pin_15;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;         //�������
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;//�ٶ�50MHz
    GPIO_Init(GPIOD, &GPIO_InitStructure);
    GPIO_SetBits(GPIOD,GPIO_Pin_1|GPIO_Pin_4|GPIO_Pin_5|GPIO_Pin_15);

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;//��������
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;//�ٶ�50MHz
    GPIO_Init(GPIOE, &GPIO_InitStructure);

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10|GPIO_Pin_12;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;         //�������
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;//�ٶ�50MHz
    GPIO_Init(GPIOE, &GPIO_InitStructure);
    GPIO_SetBits(GPIOE,GPIO_Pin_10|GPIO_Pin_12);*/

    GPIO_InitTypeDef GPIO_InitStruct0 = {0};
    __HAL_RCC_GPIOI_CLK_ENABLE();
    GPIO_InitStruct0.Pin = GPIO_PIN_1|GPIO_PIN_3;
    GPIO_InitStruct0.Mode = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct0.Pull = GPIO_NOPULL;
    GPIO_InitStruct0.Speed = GPIO_SPEED_FREQ_LOW;
    HAL_GPIO_Init(GPIOI, &GPIO_InitStruct0);//MOSI MISO CLK
    //
    HAL_GPIO_WritePin(GPIOI, GPIO_PIN_1|GPIO_PIN_3 ,GPIO_PIN_SET);

    GPIO_InitTypeDef GPIO_InitStruct00 = {0};
    __HAL_RCC_GPIOH_CLK_ENABLE();
    GPIO_InitStruct00.Pin = GPIO_PIN_7|GPIO_PIN_9|GPIO_PIN_8|GPIO_PIN_10;
    GPIO_InitStruct00.Mode = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct00.Pull = GPIO_NOPULL;
    GPIO_InitStruct00.Speed = GPIO_SPEED_FREQ_LOW;
    HAL_GPIO_Init(GPIOH, &GPIO_InitStruct00);//MOSI PH14 CS1 CS2
    //
    HAL_GPIO_WritePin(GPIOH, GPIO_PIN_7|GPIO_PIN_9|GPIO_PIN_8|GPIO_PIN_10, GPIO_PIN_SET);

    GPIO_InitTypeDef GPIO_InitStruct1 = {0};
    __HAL_RCC_GPIOI_CLK_ENABLE();
    GPIO_InitStruct1.Pin = GPIO_PIN_2;
    GPIO_InitStruct1.Mode = GPIO_MODE_INPUT;
    GPIO_InitStruct1.Pull = GPIO_PULLUP;
    GPIO_InitStruct1.Speed = GPIO_SPEED_FREQ_LOW;
    HAL_GPIO_Init(GPIOI, &GPIO_InitStruct1); //MISO

/*
    GPIO_InitTypeDef GPIO_InitStruct3= {0};
    __HAL_RCC_GPIOC_CLK_ENABLE();
    GPIO_InitStruct3.Pin = GPIO_PIN_6|GPIO_PIN_7;
    GPIO_InitStruct3.Mode = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct3.Pull = GPIO_NOPULL;
    GPIO_InitStruct3.Speed = GPIO_SPEED_FREQ_LOW;
    // GPIO_InitStruct.Alternate = GPIO_AF1_TIM2;
    HAL_GPIO_Init(GPIOC, &GPIO_InitStruct3); //DC RES
    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_6|GPIO_PIN_7, GPIO_PIN_SET);*/

    GPIO_InitTypeDef GPIO_InitStruct4= {0};
    __HAL_RCC_GPIOD_CLK_ENABLE();
    GPIO_InitStruct4.Pin = GPIO_PIN_13;
    GPIO_InitStruct4.Mode = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct4.Pull = GPIO_NOPULL;
    GPIO_InitStruct4.Speed = GPIO_SPEED_FREQ_LOW;
    HAL_GPIO_Init(GPIOD, &GPIO_InitStruct4); //blk
    HAL_GPIO_WritePin(GPIOD, GPIO_PIN_13, GPIO_PIN_SET);

  /*  rt_pin_mode(CLK,PIN_MODE_OUTPUT);
    rt_pin_mode(MOSI,PIN_MODE_OUTPUT);
    rt_pin_mode(RES,PIN_MODE_OUTPUT);
    rt_pin_mode(DC,PIN_MODE_OUTPUT);
    rt_pin_mode(BLK,PIN_MODE_OUTPUT);
    rt_pin_mode(MISO,PIN_MODE_INPUT_PULLUP);
    rt_pin_mode(CS1,PIN_MODE_OUTPUT);
    rt_pin_mode(CS2,PIN_MODE_OUTPUT);*/

}


/******************************************************************************
      ����˵����LCD��������д�뺯��
      ������ݣ�dat  Ҫд��Ĵ�������
      ����ֵ��  ��
******************************************************************************/
void LCD_Writ_Bus(rt_uint8_t dat)
{
    rt_uint8_t i;
    LCD_CS_Clr();
    for(i=0;i<8;i++)
    {
        LCD_SCLK_Clr();
        if(dat&0x80)
        {
           LCD_MOSI_Set();
        }
        else
        {
           LCD_MOSI_Clr();
        }
        LCD_SCLK_Set();
        dat<<=1;
    }
  LCD_CS_Set();
}


/******************************************************************************
      ����˵����LCDд������
      ������ݣ�dat д�������
      ����ֵ��  ��
******************************************************************************/
void LCD_WR_DATA8(rt_uint8_t dat)
{
    LCD_Writ_Bus(dat);
}


/******************************************************************************
      ����˵����LCDд������
      ������ݣ�dat д�������
      ����ֵ��  ��
******************************************************************************/
void LCD_WR_DATA(rt_uint16_t dat)
{
    LCD_Writ_Bus(dat>>8);
    LCD_Writ_Bus(dat);
}


/******************************************************************************
      ����˵����LCDд������
      ������ݣ�dat д�������
      ����ֵ��  ��
******************************************************************************/
void LCD_WR_REG(rt_uint8_t dat)
{
    LCD_DC_Clr();//д����
    LCD_Writ_Bus(dat);
    LCD_DC_Set();//д����
}


/******************************************************************************
      ����˵����������ʼ�ͽ�����ַ
      ������ݣ�x1,x2 �����е���ʼ�ͽ�����ַ
                y1,y2 �����е���ʼ�ͽ�����ַ
      ����ֵ��  ��
******************************************************************************/
void LCD_Address_Set(rt_uint16_t x1,rt_uint16_t y1,rt_uint16_t x2,rt_uint16_t y2)
{
        LCD_WR_REG(0x2a);//�е�ַ����
        LCD_WR_DATA(x1);
        LCD_WR_DATA(x2);
        LCD_WR_REG(0x2b);//�е�ַ����
        LCD_WR_DATA(y1);
        LCD_WR_DATA(y2);
        LCD_WR_REG(0x2c);//������д
}

/******************************************************************************
      ����˵����LCD��ʼ������
      ������ݣ���
      ����ֵ��  ��
******************************************************************************/
void LCD_Init(void)
{
  if(Chip_Selection==0)  //��ʼ��ILI9341
    {
    LCD_GPIO_Init();//��ʼ��GPIO

    LCD_RES_Clr();//��λ
    rt_thread_mdelay(100);
    LCD_RES_Set();
    rt_thread_mdelay(100);

    LCD_BLK_Set();//�򿪱���
  rt_thread_mdelay(100);

    //************* Start Initial Sequence **********//
    LCD_WR_REG(0x11); //Sleep out
    rt_thread_mdelay(120);              //Delay 120ms
    //************* Start Initial Sequence **********//
    LCD_WR_REG(0xCF);
    LCD_WR_DATA8(0x00);
    LCD_WR_DATA8(0xC1);
    LCD_WR_DATA8(0X30);
    LCD_WR_REG(0xED);
    LCD_WR_DATA8(0x64);
    LCD_WR_DATA8(0x03);
    LCD_WR_DATA8(0X12);
    LCD_WR_DATA8(0X81);
    LCD_WR_REG(0xE8);
    LCD_WR_DATA8(0x85);
    LCD_WR_DATA8(0x00);
    LCD_WR_DATA8(0x79);
    LCD_WR_REG(0xCB);
    LCD_WR_DATA8(0x39);
    LCD_WR_DATA8(0x2C);
    LCD_WR_DATA8(0x00);
    LCD_WR_DATA8(0x34);
    LCD_WR_DATA8(0x02);
    LCD_WR_REG(0xF7);
    LCD_WR_DATA8(0x20);
    LCD_WR_REG(0xEA);
    LCD_WR_DATA8(0x00);
    LCD_WR_DATA8(0x00);
    LCD_WR_REG(0xC0); //Power control
    LCD_WR_DATA8(0x1D); //VRH[5:0]
    LCD_WR_REG(0xC1); //Power control
    LCD_WR_DATA8(0x12); //SAP[2:0];BT[3:0]
    LCD_WR_REG(0xC5); //VCM control
    LCD_WR_DATA8(0x33);
    LCD_WR_DATA8(0x3F);
    LCD_WR_REG(0xC7); //VCM control
    LCD_WR_DATA8(0x92);
    LCD_WR_REG(0x3A); // Memory Access Control
    LCD_WR_DATA8(0x55);
    LCD_WR_REG(0x36); // Memory Access Control
    if(USE_HORIZONTAL==0)LCD_WR_DATA8(0x08);
    else if(USE_HORIZONTAL==1)LCD_WR_DATA8(0xC8);
    else if(USE_HORIZONTAL==2)LCD_WR_DATA8(0x78);
    else LCD_WR_DATA8(0xA8);
    LCD_WR_REG(0xB1);
    LCD_WR_DATA8(0x00);
    LCD_WR_DATA8(0x12);
    LCD_WR_REG(0xB6); // Display Function Control
    LCD_WR_DATA8(0x0A);
    LCD_WR_DATA8(0xA2);

    LCD_WR_REG(0x44);
    LCD_WR_DATA8(0x02);

    LCD_WR_REG(0xF2); // 3Gamma Function Disable
    LCD_WR_DATA8(0x00);
    LCD_WR_REG(0x26); //Gamma curve selected
    LCD_WR_DATA8(0x01);
    LCD_WR_REG(0xE0); //Set Gamma
    LCD_WR_DATA8(0x0F);
    LCD_WR_DATA8(0x22);
    LCD_WR_DATA8(0x1C);
    LCD_WR_DATA8(0x1B);
    LCD_WR_DATA8(0x08);
    LCD_WR_DATA8(0x0F);
    LCD_WR_DATA8(0x48);
    LCD_WR_DATA8(0xB8);
    LCD_WR_DATA8(0x34);
    LCD_WR_DATA8(0x05);
    LCD_WR_DATA8(0x0C);
    LCD_WR_DATA8(0x09);
    LCD_WR_DATA8(0x0F);
    LCD_WR_DATA8(0x07);
    LCD_WR_DATA8(0x00);
    LCD_WR_REG(0XE1); //Set Gamma
    LCD_WR_DATA8(0x00);
    LCD_WR_DATA8(0x23);
    LCD_WR_DATA8(0x24);
    LCD_WR_DATA8(0x07);
    LCD_WR_DATA8(0x10);
    LCD_WR_DATA8(0x07);
    LCD_WR_DATA8(0x38);
    LCD_WR_DATA8(0x47);
    LCD_WR_DATA8(0x4B);
    LCD_WR_DATA8(0x0A);
    LCD_WR_DATA8(0x13);
    LCD_WR_DATA8(0x06);
    LCD_WR_DATA8(0x30);
    LCD_WR_DATA8(0x38);
    LCD_WR_DATA8(0x0F);
    LCD_WR_REG(0x29); //Display on
 }
    else          //��ʼ��ST7789
    {
        LCD_GPIO_Init();//��ʼ��GPIO
        LCD_RES_Clr();  //��λ
        rt_thread_mdelay(100);
        LCD_RES_Set();
        rt_thread_mdelay(100);
        LCD_BLK_Set();//�򿪱���
        rt_thread_mdelay(500);
        LCD_WR_REG(0x11);
        rt_thread_mdelay(100); //Delay 120ms
//************* Start Initial Sequence **********//
//------------------------------display and color format setting--------------------------------//

        LCD_WR_REG(0X36);// Memory Access Control
        if(USE_HORIZONTAL==0)LCD_WR_DATA8(0x00);
        else if(USE_HORIZONTAL==1)LCD_WR_DATA8(0xC0);
        else if(USE_HORIZONTAL==2)LCD_WR_DATA8(0x70);
        else LCD_WR_DATA8(0xA0);
        LCD_WR_REG(0X3A);
        LCD_WR_DATA8(0X05);
    //--------------------------------ST7789S Frame rate setting-------------------------

        LCD_WR_REG(0xb2);
        LCD_WR_DATA8(0x0c);
        LCD_WR_DATA8(0x0c);
        LCD_WR_DATA8(0x00);
        LCD_WR_DATA8(0x33);
        LCD_WR_DATA8(0x33);
        LCD_WR_REG(0xb7);
        LCD_WR_DATA8(0x35);
        //---------------------------------ST7789S Power setting-----------------------------

        LCD_WR_REG(0xbb);
        LCD_WR_DATA8(0x35);
        LCD_WR_REG(0xc0);
        LCD_WR_DATA8(0x2c);
        LCD_WR_REG(0xc2);
        LCD_WR_DATA8(0x01);
        LCD_WR_REG(0xc3);
        LCD_WR_DATA8(0x13);
        LCD_WR_REG(0xc4);
        LCD_WR_DATA8(0x20);
        LCD_WR_REG(0xc6);
        LCD_WR_DATA8(0x0f);
        LCD_WR_REG(0xca);
        LCD_WR_DATA8(0x0f);
        LCD_WR_REG(0xc8);
        LCD_WR_DATA8(0x08);
        LCD_WR_REG(0x55);
        LCD_WR_DATA8(0x90);
        LCD_WR_REG(0xd0);
        LCD_WR_DATA8(0xa4);
        LCD_WR_DATA8(0xa1);
        //--------------------------------ST7789S gamma setting------------------------------
        LCD_WR_REG(0xe0);
        LCD_WR_DATA8(0xd0);
        LCD_WR_DATA8(0x00);
        LCD_WR_DATA8(0x06);
        LCD_WR_DATA8(0x09);
        LCD_WR_DATA8(0x0b);
        LCD_WR_DATA8(0x2a);
        LCD_WR_DATA8(0x3c);
        LCD_WR_DATA8(0x55);
        LCD_WR_DATA8(0x4b);
        LCD_WR_DATA8(0x08);
        LCD_WR_DATA8(0x16);
        LCD_WR_DATA8(0x14);
        LCD_WR_DATA8(0x19);
        LCD_WR_DATA8(0x20);
        LCD_WR_REG(0xe1);
        LCD_WR_DATA8(0xd0);
        LCD_WR_DATA8(0x00);
        LCD_WR_DATA8(0x06);
        LCD_WR_DATA8(0x09);
        LCD_WR_DATA8(0x0b);
        LCD_WR_DATA8(0x29);
        LCD_WR_DATA8(0x36);
        LCD_WR_DATA8(0x54);
        LCD_WR_DATA8(0x4b);
        LCD_WR_DATA8(0x0d);
        LCD_WR_DATA8(0x16);
        LCD_WR_DATA8(0x14);
        LCD_WR_DATA8(0x21);
        LCD_WR_DATA8(0x20);
        LCD_WR_REG(0x29);
}
}
