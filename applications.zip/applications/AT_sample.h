#ifndef _AT_SAMPLE_H
#define _AT_SAMPLE_H

int AT_sample();
extern rt_mailbox_t AT_mb;
extern rt_event_t alarm_event;
#endif
