/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2023-07-19     tangliwei       the first version
 */
#ifndef _MPU_APP_H_
#define _MPU_APP_H_

int mpu_sample();

#endif /* APPLICATIONS_MPU_APP_H_ */
